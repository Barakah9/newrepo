<?php 
	define('SITEURL', 'http://localhost:8080/phpmultilingualblog/');
	define('LOCALHOST', 'my-db.coh6unl0oehy.us-east-1.rds.amazonaws.com');
	define('USERNAME', 'admin1');
	define('PASSWORD', 'zAsK1989sk');
	define('DBNAME', 'mlb2018');
?>
