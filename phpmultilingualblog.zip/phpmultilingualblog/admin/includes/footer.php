<footer class="footer">
		<div class="wrapper">
			<p>
				<?php echo $lang['copy_right'] ?>
			</p>
			<p>
				<?php echo $lang['developed_by'] ?> - <a href="https://www.vijaythapa.com/" title="Web Developer in Nepal"><?php echo $lang['author'] ?></a>
			</p>
		</div>
	</footer>
</body>
</html>