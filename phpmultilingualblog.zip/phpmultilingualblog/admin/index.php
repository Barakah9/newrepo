<?php 
	include('../languages/lang_config.php');
	include('config/apply.php');
	include('config/login_check.php');
	include('includes/header.php');
	include('includes/body.php');
	include('includes/footer.php');
?>