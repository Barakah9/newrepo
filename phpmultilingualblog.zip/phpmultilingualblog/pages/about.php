<div class="main">
	<div class="body">
		<h2><?php echo $lang['about'] ?></h2>
		<br>
		<p>
			<?php echo $lang['about_content'] ?>
		</p>
		<br>
		<p>
			<?php echo $lang['contact'] ?> <a href="mailto:hi@vijaythapa.com?Subject=multi-lingual%20website" target="_top">hi@vijaythapa.com</a>
		</p>

	</div>
</div>