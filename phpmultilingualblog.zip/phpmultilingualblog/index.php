<?php 
	include('languages/lang_config.php');
	include('admin/config/apply.php');
	include('includes/header.php');
	include('includes/body.php');
	include('includes/footer.php');
?>
